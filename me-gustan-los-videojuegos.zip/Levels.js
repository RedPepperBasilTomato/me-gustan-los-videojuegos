function playLvl1(){ //CORAL
  screen = 30;
  lvl = 1;
  totHealth = 100;
   background(132, 141, 217); 
 
  playerSetUp();

  if (!lvl1End) {  // Check if lvl1End has not been created
    lvl1End = new Sprite(1450, 50, 20, 40, "k"); 
  }

  
    coral1 = new corals.Sprite(coralImg,200, 300, "n");
     coral2 = new corals.Sprite(coralImg, 350, 300, "n");
  

}//end LVL 1 ====================================================

function playLvl2(){ //KELP
  screen = 40; 
  totHealth = 100;
  playerSetUp();

  if (!lvl2End) // Check if lvl1End has not been created
  {  
    lvl2End = new Sprite(300, 50, 20, 40, "k");
    kelp1 = new kelps.Sprite(kelpImg, 200, 300, "n");
  }


}///end LVL 2 ====================================================

function playLvl3(){ //SUNKEN SHIP
  screen = 50; 
  totHealth = 100;
  playerSetUp();

  if (!lvl3End) {  // Check if lvl1End has not been created
    lvl3End = new Sprite(300, 50, 20, 40, "k");
  }


}// end LVL 3 ==========================================================

function playLvl4(){ //WHALE FALL
  screen = 60; 
  totHealth = 100;
  playerSetUp();


  if (!lvl4End) {  // Check if lvl1End has not been created
    lvl4End = new Sprite(300, 50, 20, 40, "k");
  }


}//end LVL 4=================================================================

function playLvl5(){ //UNDERWATER VOLCANO 
  screen = 70; 
  totHealth = 100;
  playerSetUp();


  if (!lvl5End) {  // Check if lvl1End has not been created
    lvl5End = new Sprite(300, 50, 20, 40, "k");
  }


}//end LVL 5=================================================================